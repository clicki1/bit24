<template>
    <div>
        <h1>Index</h1>
    </div>
</template>

<script>
export default {
    name: "Index"
}
</script>


<style scoped>

</style>
